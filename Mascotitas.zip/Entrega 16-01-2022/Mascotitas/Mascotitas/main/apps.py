from django.apps import AppConfig


class PrincipalConfig(AppConfig):
    name = 'main'
    
class MainConfig(AppConfig):
    name = 'main'
