#encoding:utf-8
from main.models import *
from django.shortcuts import render, HttpResponse
from django.conf import settings
from django import forms
from django.db import connection
from main import populateDB
import os, os.path
import shutil
import shelve

from whoosh import qparser
from whoosh.fields import Schema, TEXT, KEYWORD, ID, NUMERIC,BOOLEAN,DATETIME
from whoosh import index
from django.shortcuts import get_object_or_404

from main.recommendations import getRecommendations, transformPrefs,topMatches
from main.forms import *


def cargar(request):
    url='https://petshelter.miwuki.com/adoptar-en-'
    populateDB.populateDatabase(url)
    rat = Rating.objects.all().count()
    usu = Usuario.objects.all().count()
    mas = Mascota.objects.all().count()
    html="<html><h1><a href='/'>Inicio</a></h1><br><body>Datos cargados correctamente\n" + "Ratings: " + str(rat) + " ; " + "Usuarios: " + str(usu) + " ; " + "Mascotas: " + str(mas) +"</body></htm>"
   
    return HttpResponse(html)

def inicio(request):
    mascotas=Mascota.objects.all()
    ratings=Rating.objects.all()
    usuarios=Usuario.objects.all()
    return render(request,'inicio.html', {'mascotas':mascotas,'usuarios':usuarios,'valoraciones':ratings})

def mascotas(request):
    mascotas = Mascota.objects.all()
    return render(request,'mascotas.html', {'mascotas':mascotas})

def createWhoosh(request):
  # eliminamos el directorio del índice, si existe
    if os.path.exists("Index"):
        shutil.rmtree("Index")
    os.mkdir("Index")

    # creamos el índice
    ix = index.create_in("Index", schema=getSchem())
    writer = ix.writer()
    i=0
    listaMascotas=Mascota.objects.all()
    for m in listaMascotas:
        writer.add_document(url=str(m.url),nombre=str(m.nombre),localizacion=str(m.localizacion),especie=str(m.especie),estado=str(m.estado),rating=str(m.favoritos)
        ,fechaNacimiento=str(m.fechaNacimiento),sexo=str(m.sexo),tamaño=str(m.tamaño),peso=int(m.peso),nivelActividad=str(m.nivelActividad)
        ,vacunado=str(m.vacunado),desparasitado=str(m.desparasitado),sano=str(m.sano),esterilizado=str(m.esterilizado),identificado=str(m.identificado),microchip=str(m.microchip)
        ,historia=str(m.historia),requisitos=str(m.requisitos))
        i+=1 
    writer.commit() 
    print(str(i)+" mascotas indexadas")
    return render(request,'index.html')


def mejoresMascotas(request):
    mascotas = Mascota.objects.all().order_by('-favoritos')[:20]       
    return render(request,'mejoresMascotas.html',{'mascotas':mascotas})

#muestra detalles de una mascota
def detalleMascota(request, url):
    mascota = get_object_or_404(Mascota, pk=url)
    return render(request,'mascota.html',{'mascota':mascota})


def buscar(request):
    if request.method == 'GET':
        formulario = GeneralPetForm(request.GET,request.FILES)
        if formulario.is_valid():
            ix = index.open_dir("Index")
            with ix.searcher() as searcher:
                general = formulario.cleaned_data['general']
                query = qparser.MultifieldParser(
                    ['url','nombre','localizacion','especie','estado','favoritos'
    ,'fechaNacimiento','sexo','tamaño','peso','nivelActividad'
    ,'vacunado','desparasitado','sano','esterilizado','identificado','microchip'
    ,'historia','requisitos'], ix.schema).parse(general)
                mascotas = searcher.search(query, limit=20)
                return render(request, 'busquedaGeneral.html', {'mascotas': mascotas, 'formulario': formulario,'encabezado': 'Búsqueda general de Mascotas'})
    formulario = GeneralPetForm()
    return render(request, 'searchView.html', {'formulario': formulario, 'encabezado': 'Búsqueda general de Mascotas'})

def buscarEstado(request):
    if request.method == 'GET':
        formulario = EstadoPetForm(request.GET,request.FILES)
        if formulario.is_valid():
            ix = index.open_dir("Index")
            with ix.searcher() as searcher:
                formulario.clean()
                estado=formulario.cleaned_data['estado']
                query = qparser.QueryParser("estado", ix.schema).parse(estado)
                mascotas = searcher.search(query, limit=20)
                return render(request, 'busquedaGeneral.html', {'mascotas': mascotas, 'formulario': formulario,'encabezado': 'Búsqueda por estado de Mascotas'})
    formulario = EstadoPetForm()
    return render(request, 'searchView.html', {'formulario': formulario, 'encabezado': 'Busqueda por estado de Mascotas'})

def buscarLocalizacionAndText(request):
    if request.method == 'GET':
        formulario = LocalizacionAndTextForm(request.GET,request.FILES)
        if formulario.is_valid():
            ix = index.open_dir("Index")
            with ix.searcher() as searcher:
                formulario.clean()
                localizacion = formulario.cleaned_data['localizacion']
                historia = ' historia:'+formulario.cleaned_data['text']+']'
                requisitos = ' requisitos:'+formulario.cleaned_data['text']+']'
                query = qparser.MultifieldParser(
                    ['localizacion'],ix.schema).parse(localizacion +' AND'+historia+' OR '+localizacion +' AND'+requisitos)
                print(query)
                mascotas = searcher.search(query, limit=20)
                return render(request, 'busquedaGeneral.html', {'mascotas': mascotas, 'formulario': formulario,'encabezado': 'Búsqueda por localizacion y textos de Mascotas'})

    formulario = LocalizacionAndTextForm()
    return render(request, 'searchView.html', {'formulario': formulario, 'encabezado': 'Búsqueda por localización y textos de Mascotas'})

def recomendarMascotas(request):
    if request.method=='GET':
        formulario = RecomendacionUsuarioForm(request.GET, request.FILES)
        if formulario.is_valid():
            idUsuario = formulario.cleaned_data['idUsuario']
            usuario = get_object_or_404(Usuario, pk=idUsuario)
            shelf = shelve.open("dataRS.dat")
            Prefs = shelf['Prefs']
            shelf.close()
            rankings = getRecommendations(Prefs,int(idUsuario))
            recommended = rankings[:5]
            mascotas = []
            scores = []
            for re in recommended:
                mascotas.append(Mascota.objects.get(pk=re[1]))
                scores.append(re[0])
            items= zip(mascotas,scores)
            return render(request,'similarPets.html', {'usuario': usuario, 'items': items})
    formulario = RecomendacionUsuarioForm()
    return render(request,'searchView.html', {'formulario': formulario,'encabezado': 'Mascotas recomendadas'})

# def similarPets(request):
#     mascota = None
#     if request.method=='GET':
#         formulario = PetForm(request.GET, request.FILES)
#         if formulario.is_valid():
#             idMascota = formulario.cleaned_data['url']
#             mascota = get_object_or_404(Mascota, pk=idMascota)
#             shelf = shelve.open("dataRS.dat")
#             ItemsPrefs = shelf['ItemsPrefs']
#             shelf.close()
#             recommended = topMatches(ItemsPrefs, int(idMascota),n=3)
#             mascotas = []
#             similar = []
#             for re in recommended:
#                 mascotas.append(Mascota.objects.get(pk=re[1]))
#                 similar.append(re[0])
#             items= zip(mascota,similar)
#             return render(request,'similarPets.html', {'mascota': mascota,'mascotas': items})
#     formulario = PetForm()
#     return render(request,'search_pet.html', {'formulario': formulario}) 


# Funcion que carga en el diccionario Prefs todas las puntuaciones de usuarios a peliculas. Tambien carga el diccionario inverso
# Serializa los resultados en dataRS.dat
def loadDict():
    Prefs={}   # matriz de usuarios y puntuaciones a cada a items
    shelf = shelve.open("dataRS.dat")
    ratings = Rating.objects.all()
    for ra in ratings:
        user = int(ra.Usuario.pk)
        itemid = str(ra.Mascota.pk)
        rating = float(ra.rating)
        Prefs.setdefault(user, {})
        Prefs[user][itemid] = rating
    shelf['Prefs']=Prefs
    shelf['ItemsPrefs']=transformPrefs(Prefs)
    shelf.close()

def loadRS(request):
    loadDict()
    return render(request,'loadRS.html')

def getSchem(): 
    schem = Schema(url=ID(stored=True),
                   nombre=TEXT(stored=True),
                   localizacion=TEXT(stored=True),
                   especie=TEXT(stored=True),
                   estado=TEXT(stored=True),
                   rating=TEXT(stored=True),

                   fechaNacimiento=DATETIME(stored=True),
                   sexo=TEXT(stored=True),
                   tamaño=TEXT(stored=True),
                   peso=NUMERIC(stored=True,numtype=float),
                   nivelActividad=TEXT(stored=True),

                   vacunado=BOOLEAN(stored=True),
                   desparasitado=BOOLEAN(stored=True),
                   sano=BOOLEAN(stored=True),
                   esterilizado=BOOLEAN(stored=True),
                   identificado=BOOLEAN(stored=True),
                   microchip=BOOLEAN(stored=True),
                   
                   historia=TEXT(stored=False),
                   requisitos=TEXT(stored=False))
    return schem
