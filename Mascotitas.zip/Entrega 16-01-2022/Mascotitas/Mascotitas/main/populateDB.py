#encoding:utf-8
import os, os.path
from main.models import *

from bs4 import BeautifulSoup
import urllib.request

import random
from django.shortcuts import get_object_or_404 

def extraerHtml(url):
    url='https://petshelter.miwuki.com/adoptar-en-'
    
    return populateDatabase(url)

def populateDatabase(url):
    Rating.objects.all().delete()
    Mascota.objects.all().delete()
    Usuario.objects.all().delete()

    # localidades = ['sevilla','granada','malaga','almeria','huelva','cadiz','jaen','cordoba','alava','albacete','alicante','asturias','badajoz','barcerlona','burgos','caceres','cantabria','castellon','ciudad-real','a-coruna','cuenca','girona','guadalajara','guipuzcoa','huesca','baleares','leon','lleida','lugo','madrid','murcia','navarra','ourense','palencia','las-palmas','pontevedra','la-rioja','salamanca','segovia','soria','tarragona','santa-cruz-de-tenerife','teruel','toledo','valencia','vizcaya','zamora','zaragoza']
    localidades = ['sevilla','granada','malaga','almeria','huelva','cadiz','jaen','cordoba','madrid','barcelona','valencia','zaragoza','asturias']
    # localidades = ['sevilla','granada','malaga','almeria','huelva','cadiz','jaen','cordoba']
    # localidades=['sevilla']

    n=len(localidades)*90
    crearUsuarios(n)
 
    for localidad in localidades:
        req = urllib.request.Request(url+localidad, headers={'User-Agent': 'Mozilla/5.0'})
        f = urllib.request.urlopen(req).read()
        s = BeautifulSoup(f,"lxml")        
        
        listaMascotas=[]

        for i in s.find_all("div", class_= ["m-portlet","m-animal"]):
            urlMascota=i.find("a",href=True)['href']
            nombreMascota= i.find("span",class_=["m-animal__nombre"]).text.strip()
            localizacionMascota=i.find("div",class_=["info"]).text.strip()
            especieMascota=i.find("span",class_=["m-animal__especie"]).text.strip()
            estadoMascota=i.find("div",class_=["m-portlet__foot","m-animal--e1"]).text.strip()
            ratingMascota=i.find("div",class_=["fav"]).text.strip()
             
            m=crearMascota(urlMascota,nombreMascota,localizacionMascota,especieMascota,estadoMascota,ratingMascota)
            for i in range(0,int(ratingMascota)):
                id=random.randint(1,n)
                u=get_object_or_404(Usuario,idUsuario=id)
                Rating.objects.create(Mascota=m,Usuario=u,rating=random.randint(1,5))



def crearMascota(urlMascota,nombreMascota,localizacionMascota,especieMascota,estadoMascota,ratingMascota):
    req = urllib.request.Request('https://petshelter.miwuki.com/'+urlMascota, headers={'User-Agent': 'Mozilla/5.0'})
    f = urllib.request.urlopen(req)
    s = BeautifulSoup(f,"lxml")

    fechaNacimiento=s.find_all("span", class_= ["m-list-timeline__time"])[1].text.strip()
    if(fechaNacimiento==""):
        fechaNacimiento="2000-05-29"
    sexo=s.find_all("span", class_= ["m-list-timeline__time"])[2].text.strip()
    tamaño=s.find_all("span", class_= ["m-list-timeline__time"])[3].text.strip()
    peso=s.find_all("span", class_= ["m-list-timeline__time"])[4].text.strip().replace(" Kg.","")
    actividad=s.find_all("span", class_= ["m-list-timeline__time"])[5].text.strip()
    
    vacunado=parseBoolean(s.find_all("span", class_= ["m-badge m-badge--miwuki","m-badge--wide"])[0].text.strip())
    desparasitado=parseBoolean(s.find_all("span", class_= ["m-badge m-badge--miwuki","m-badge--wide"])[1].text.strip())
    sano=parseBoolean(s.find_all("span", class_= ["m-badge m-badge--miwuki","m-badge--wide"])[2].text.strip())
    esterilizado=parseBoolean(s.find_all("span", class_= ["m-badge m-badge--miwuki","m-badge--wide"])[3].text.strip())
    identificado=parseBoolean(s.find_all("span", class_= ["m-badge m-badge--miwuki","m-badge--wide"])[4].text.strip())
    microchip=parseBoolean(s.find_all("span", class_= ["m-badge m-badge--miwuki","m-badge--wide"])[5].text.strip())
    
    aux=s.find_all("div",class_="m-portlet__body")
    textosUtilidad=[div.text for div in aux]
    textosFinal=list(filter(lambda x:'Mi historia:' in x or 'Requisitos para la adopción:' in x, textosUtilidad))
    historia=textosFinal[0].replace("Mi historia:","").strip()
    requisitos=textosFinal[1].replace("Requisitos para la adopción:","")


    m=Mascota.objects.create(url=urlMascota,nombre=nombreMascota,localizacion=localizacionMascota,especie=especieMascota,estado=estadoMascota,favoritos=ratingMascota
    ,fechaNacimiento=fechaNacimiento,sexo=sexo,tamaño=tamaño,peso=peso,nivelActividad=actividad
    ,vacunado=vacunado,desparasitado=desparasitado,sano=sano,esterilizado=esterilizado,identificado=identificado,microchip=microchip
    ,historia=historia,requisitos=requisitos)

    return m
 
    

def crearUsuarios(n): 
    for u in range(1,n+1):
        Usuario.objects.create(idUsuario=u)
    

def parseBoolean(boolean):
    boolLow=boolean.lower()
    return True if boolLow=='sí' or boolLow=='si' else False
