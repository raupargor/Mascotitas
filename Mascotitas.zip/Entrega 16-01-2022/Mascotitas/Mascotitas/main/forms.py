# -*- encoding: utf-8 -*-
from django import forms#En este tenemos que meter los formularios como si fueran clases
from main.models import *
from django.db.models import Count

class UserForm(forms.Form):
    id = forms.CharField(label='User ID')
    
class GeneralPetForm(forms.Form):
    general = forms.CharField(label='Busqueda')

class EstadoPetForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(EstadoPetForm, self).__init__(*args, **kwargs)
    
        valoresEstado = set([(m.estado,m.estado) for m in Mascota.objects.all()])

        self.fields['estado'] = forms.ChoiceField(choices=valoresEstado, label='Estado')#choices necesita el valor que se busca y lo que ve el usuario


class LocalizacionAndTextForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(LocalizacionAndTextForm, self).__init__(*args, **kwargs)
        valoresLoc = set([(m.localizacion,m.localizacion) for m in Mascota.objects.all()])
        self.fields['localizacion'] = forms.ChoiceField(choices=valoresLoc, label='Localizacion')
        self.fields['text'] = forms.CharField(label='Texto')

# class LocalizacionBoolsPetForm(forms.Form):
#     def __init__(self, *args, **kwargs):
#         super(LocalizacionBoolsPetForm, self).__init__(*args, **kwargs)
#         posiblesValores=set()
#         for m in Mascota.objects.all():
#             valores = [(tipo.strip(), tipo.strip()) for tipo in m.localizacion.split(',')]
#             posiblesValores.update(valores)

#         self.fields['localizacion'] = forms.ChoiceField(choices=posiblesValores, label='Localizacion')
#         self.fields['text'] = forms.CharField(label='Búsqueda')

class RecomendacionUsuarioForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super(RecomendacionUsuarioForm, self).__init__(*args, **kwargs)

        usuarios =[u.idUsuario for u in Usuario.objects.all()] 
        usuarios.sort()

        ratingsPorUsuarioDict = Rating.objects.values('Usuario__idUsuario').annotate(dcount=Count('Usuario__idUsuario')).order_by()
        listaUsuariosValidos = [(rating['Usuario__idUsuario'], rating['Usuario__idUsuario']) for rating in list(filter(lambda e: e['dcount'] >= 8, ratingsPorUsuarioDict))]

        self.fields['idUsuario'] = forms.ChoiceField(choices=listaUsuariosValidos,label='Busqueda')

# class PetForm(forms.Form):
#     pets = set([(m.nombre,m.nombre) for m in Mascota.objects.all()])
#     url = forms.ChoiceField(choices=pets, label='Mascota')