#encoding:utf-8
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator

class Usuario(models.Model):
    idUsuario= models.IntegerField(primary_key=True,default=0)

    def __str__(self):
        return str(self.idUsuario)


class Mascota(models.Model):
    url=models.CharField(max_length=200,primary_key=True,default='https://petshelter.miwuki.com/adoptar-en-sevilla-99999')
    nombre= models.TextField(null=True)
    localizacion = models.CharField(max_length=30,null=True)
    especie=models.CharField(max_length=30,null=True)
    estado= models.CharField(max_length=20,null=True)#en adopcion, urgente, adoptado
    favoritos=models.IntegerField(null=True)
    
    fechaNacimiento = models.DateField(null=True)
    sexo = models.CharField(max_length=20,null=True)
    tamaño=models.CharField(max_length=20,null=True)
    peso=models.DecimalField(null=True,decimal_places=2,max_digits=10)
    nivelActividad=models.CharField(max_length=20,null=True)

    vacunado=models.BooleanField(default=False,null=True)
    desparasitado=models.BooleanField(default=False,null=True)
    sano=models.BooleanField(default=False,null=True)
    esterilizado=models.BooleanField(default=False,null=True)
    identificado=models.BooleanField(default=False,null=True)
    microchip=models.BooleanField(default=False,null=True)

    historia=models.TextField(null=True)
    requisitos=models.TextField(null=True)

    def __str__(self):
        return str(self.nombre)+',de '+str(self.localizacion)+':'+str(self.especie)+'. Estado: '+str(self.estado)

class Rating(models.Model):
    Mascota = models.ForeignKey(Mascota,on_delete=models.DO_NOTHING)
    Usuario=models.ForeignKey(Usuario,on_delete=models.DO_NOTHING)

    rating = models.FloatField(validators=[MinValueValidator(0), MaxValueValidator(5)],default=0)
    def __str__(self):
        return str(self.Mascota.nombre+' voted by user: '+str(self.Usuario.idUsuario))

