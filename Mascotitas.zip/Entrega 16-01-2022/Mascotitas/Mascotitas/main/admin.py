from django.contrib import admin
from main.models import *

admin.site.register(Rating)
admin.site.register(Usuario)
admin.site.register(Mascota)
