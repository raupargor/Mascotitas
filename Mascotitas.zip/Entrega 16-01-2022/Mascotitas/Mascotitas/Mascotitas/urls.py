
from django.contrib import admin
from django.urls import path
from main import views

urlpatterns = [  
    path('', views.inicio),
    path('cargar/', views.cargar),
    path('whoosh/',views.createWhoosh),
    path('admin/', admin.site.urls),
    path('mascotas/',views.mascotas),
    path('mascotas/<str:url>', views.detalleMascota),
    path('mejoresMascotas/',views.mejoresMascotas),
    path('busquedaGeneral/',views.buscar),
    path('busquedaEstado/',views.buscarEstado),
    path('busquedaLocalizacion/',views.buscarLocalizacionAndText),
    path('recomendaciones/',views.recomendarMascotas),
    # path('recomendacionesSimilares/',views.similarPets),
    path('loadRS/', views.loadRS),

]
